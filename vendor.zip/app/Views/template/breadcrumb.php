<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <?php echo $breadcrumb; ?>
      <!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>